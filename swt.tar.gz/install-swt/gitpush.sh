#!/bin/sh
git push -u origin master
